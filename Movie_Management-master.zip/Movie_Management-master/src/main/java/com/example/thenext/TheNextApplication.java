package com.example.thenext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheNextApplication {

    public static void main(String[] args) {

        SpringApplication.run(TheNextApplication.class, args);
    }


}
